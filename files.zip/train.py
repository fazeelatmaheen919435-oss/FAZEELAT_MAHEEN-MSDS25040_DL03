# train.py
import argparse
import csv
import os
import random
import time
import multiprocessing

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.optim as optim
from torch.utils.data import DataLoader
from tqdm import tqdm

from dataset import (BaseDataset, ContrastiveDataset, TripletDataset,
                     get_transforms, load_caltech101, split_dataset)
from loss import ContrastiveLoss, TripletLoss, batch_hard_mining
from model import EmbeddingNet, load_checkpoint, save_checkpoint
from retrieval import plot_tsne, recall_at_k, show_retrieval
from save_embeddings import save_embeddings


def set_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def init_csv(path):
    os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
    with open(path, 'w', newline='') as f:
        csv.writer(f).writerow(['epoch', 'train_loss',
                                'val_recall@1', 'val_recall@5',
                                'elapsed_sec'])


def append_csv(path, epoch, loss, r1, r5, elapsed):
    with open(path, 'a', newline='') as f:
        csv.writer(f).writerow([epoch, f'{loss:.5f}',
                                 f'{r1:.4f}', f'{r5:.4f}',
                                 f'{elapsed:.1f}'])


def get_embeddings(model, base_dataset, device, batch_size=32):
    loader = DataLoader(base_dataset, batch_size=batch_size,
                        shuffle=False, num_workers=0, pin_memory=False)
    model.eval()
    embs, labs = [], []
    with torch.no_grad():
        for imgs, labels in loader:
            embs.append(model(imgs.to(device)).cpu().numpy())
            labs.extend(labels.numpy())
    return np.concatenate(embs), np.array(labs)


def save_training_plots(exp_name, losses, r1s, r5s, test_r1, test_r5):
    os.makedirs('graphs', exist_ok=True)
    epochs = range(1, len(losses) + 1)
    fig, axes = plt.subplots(1, 3, figsize=(15, 4))

    axes[0].plot(epochs, losses, color='steelblue', marker='o', ms=3)
    axes[0].set_title(f'{exp_name} - Training Loss')
    axes[0].set_xlabel('Epoch')
    axes[0].set_ylabel('Loss')
    axes[0].grid(True, alpha=0.3)

    axes[1].plot(epochs, r1s, label='Recall@1', color='green')
    axes[1].plot(epochs, r5s, label='Recall@5', color='orange')
    axes[1].set_title(f'{exp_name} - Val Recall')
    axes[1].set_xlabel('Epoch')
    axes[1].legend()
    axes[1].grid(True, alpha=0.3)

    axes[2].bar(['Recall@1', 'Recall@5'], [test_r1, test_r5],
                color=['green', 'orange'])
    axes[2].set_title(f'{exp_name} - Test Recall')
    axes[2].set_ylim(0, 1.0)
    axes[2].grid(True, alpha=0.3)

    plt.tight_layout()
    out = f'graphs/{exp_name}_curves.png'
    plt.savefig(out, dpi=130, bbox_inches='tight')
    plt.close()
    print(f"[OK] Training curves saved -> {out}")


def run_experiment(exp_name, loss_type, args, device,
                   train_s, val_s, test_s, classes):

    print(f"\n{'='*62}")
    print(f"  {exp_name}  |  loss={loss_type}")
    print(f"{'='*62}")

    ckpt_dir = os.path.join('weights', exp_name)
    emb_dir  = os.path.join('embeddings', exp_name)
    os.makedirs(ckpt_dir, exist_ok=True)
    os.makedirs(emb_dir,  exist_ok=True)
    os.makedirs('graphs', exist_ok=True)

    best_ckpt = os.path.join(ckpt_dir, 'best.pth')
    csv_path  = os.path.join('graphs', f'{exp_name}_training_log.csv')

    train_base = BaseDataset(train_s, get_transforms(train=True))
    val_base   = BaseDataset(val_s,   get_transforms(train=False))
    test_base  = BaseDataset(test_s,  get_transforms(train=False))

    if loss_type == 'contrastive':
        train_dataset = ContrastiveDataset(train_base)
        criterion     = ContrastiveLoss(margin=1.0)
    elif loss_type == 'triplet':
        train_dataset = TripletDataset(train_base)
        criterion     = TripletLoss(margin=0.2)
    else:
        train_dataset = train_base
        criterion     = None

    train_loader = DataLoader(
        train_dataset,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=0,
        drop_last=True,
        pin_memory=False,
    )

    model = EmbeddingNet(embedding_dim=args.embedding_dim).to(device)
    optimizer = optim.Adam(
        filter(lambda p: p.requires_grad, model.parameters()),
        lr=args.lr, weight_decay=1e-4
    )
    scheduler = optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=args.epochs, eta_min=1e-6
    )

    best_r1      = 0.0
    patience_cnt = 0
    train_losses, val_r1s, val_r5s = [], [], []
    init_csv(csv_path)

    for epoch in range(1, args.epochs + 1):
        model.train()
        epoch_loss = 0.0
        n_batches  = 0
        ep_start   = time.time()

        for batch in tqdm(train_loader,
                          desc=f'  Ep {epoch:>3}/{args.epochs}',
                          leave=True):

            optimizer.zero_grad()

            if loss_type == 'contrastive':
                img1, img2, pair_label = batch
                e1   = model(img1.to(device))
                e2   = model(img2.to(device))
                loss = criterion(e1, e2, pair_label.to(device))

            elif loss_type == 'triplet':
                anc, pos, neg = batch
                ea   = model(anc.to(device))
                ep_  = model(pos.to(device))
                en   = model(neg.to(device))
                loss = criterion(ea, ep_, en)

            else:
                imgs, labels_b = batch
                embs = model(imgs.to(device))
                loss = batch_hard_mining(embs,
                                         labels_b.to(device),
                                         margin=0.2)

            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()

            epoch_loss += loss.item()
            n_batches  += 1

        scheduler.step()
        avg_loss = epoch_loss / max(n_batches, 1)
        train_losses.append(avg_loss)

        val_embs, val_labs = get_embeddings(model, val_base, device)
        r1 = recall_at_k(val_embs, val_labs, k=1)
        r5 = recall_at_k(val_embs, val_labs, k=5)
        val_r1s.append(r1)
        val_r5s.append(r5)

        elapsed = time.time() - ep_start
        append_csv(csv_path, epoch, avg_loss, r1, r5, elapsed)

        print(f"  Ep {epoch:>3}  loss={avg_loss:.4f}  "
              f"val R@1={r1:.4f}  R@5={r5:.4f}  ({elapsed:.1f}s)")

        if r1 > best_r1:
            best_r1      = r1
            patience_cnt = 0
            save_checkpoint(model, best_ckpt,
                            extra={'epoch': epoch, 'val_recall@1': r1})
        else:
            patience_cnt += 1

        if patience_cnt >= args.patience:
            print(f"  [Early stop] epoch {epoch}")
            break

    load_checkpoint(model, best_ckpt, device)

    test_embs, test_labs = get_embeddings(model, test_base, device)
    test_r1 = recall_at_k(test_embs, test_labs, k=1)
    test_r5 = recall_at_k(test_embs, test_labs, k=5)
    print(f"\n  [TEST] Recall@1={test_r1:.4f} | Recall@5={test_r5:.4f}")

    save_embeddings(test_embs, test_labs,
                    os.path.join(emb_dir, 'test'))
    train_embs_full, train_labs_full = get_embeddings(
        model,
        BaseDataset(train_s, get_transforms(train=False)),
        device
    )
    save_embeddings(train_embs_full, train_labs_full,
                    os.path.join(emb_dir, 'train'))

    save_training_plots(exp_name, train_losses,
                        val_r1s, val_r5s, test_r1, test_r5)

    plot_tsne(test_embs, test_labs,
              title=f't-SNE - {exp_name}',
              save_path=f'graphs/{exp_name}_tsne.png')

    test_paths = [s[0] for s in test_s]
    query_idxs = random.sample(range(len(test_s)), min(10, len(test_s)))
    show_retrieval(
        query_idxs, test_embs, test_paths,
        test_labs, classes, k=5,
        save_path=f'graphs/{exp_name}_retrieval.png'
    )

    return {
        'exp':     exp_name,
        'test_r1': test_r1,
        'test_r5': test_r5,
        'ckpt':    best_ckpt,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--dataset_path',  required=True)
    parser.add_argument('--epochs',        type=int,   default=25)
    parser.add_argument('--batch_size',    type=int,   default=32)
    parser.add_argument('--lr',            type=float, default=1e-4)
    parser.add_argument('--patience',      type=int,   default=6)
    parser.add_argument('--embedding_dim', type=int,   default=128)
    parser.add_argument('--seed',          type=int,   default=42)
    parser.add_argument('--exp',           default='all',
                        choices=['all', 'exp1', 'exp2', 'exp3'])
    args = parser.parse_args()

    set_seed(args.seed)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Device : {device}")

    samples, classes, _ = load_caltech101(args.dataset_path)
    train_s, val_s, test_s = split_dataset(samples)

    exp_configs = {
        'exp1': ('Exp1_Contrastive',    'contrastive'),
        'exp2': ('Exp2_Triplet_Random', 'triplet'),
        'exp3': ('Exp3_Triplet_Hard',   'hard'),
    }

    run_keys = list(exp_configs.keys()) if args.exp == 'all' \
               else [args.exp]

    results = []
    for key in run_keys:
        name, loss_type = exp_configs[key]
        r = run_experiment(name, loss_type, args, device,
                           train_s, val_s, test_s, classes)
        results.append(r)

    print('\n' + '-'*55)
    print(f"{'Experiment':<28} {'Recall@1':>10} {'Recall@5':>10}")
    print('-'*55)
    for r in results:
        print(f"{r['exp']:<28} {r['test_r1']:>10.4f} "
              f"{r['test_r5']:>10.4f}")
    print('-'*55)

    os.makedirs('graphs', exist_ok=True)
    with open('graphs/results_summary.csv', 'w', newline='') as f:
        w = csv.writer(f)
        w.writerow(['experiment', 'recall@1', 'recall@5'])
        for r in results:
            w.writerow([r['exp'],
                        f"{r['test_r1']:.4f}",
                        f"{r['test_r5']:.4f}"])
    print("[OK] Summary saved -> graphs/results_summary.csv")


if __name__ == '__main__':
    multiprocessing.freeze_support()
    main()
