# retrieval.py
"""
Retrieval evaluation utilities.
  1.7  recall_at_k
  1.8  plot_tsne
  1.9  show_retrieval
"""

import os
import random
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from PIL import Image


# ─────────────────────────────────────────────────────────────
# 1.7  Recall @ K
# ─────────────────────────────────────────────────────────────

def recall_at_k(embeddings: np.ndarray,
                labels:     np.ndarray,
                k:          int = 1) -> float:
    """
    Nearest-neighbour Recall@K.

    For every query image, retrieve k most similar embeddings
    (excluding the query itself) using cosine similarity.
    A query is a hit if ANY of the top-k neighbours shares
    the same class label.

    Args:
        embeddings : (N, D)  numpy array of L2-normalised vectors
        labels     : (N,)    integer class labels
        k          : number of neighbours to retrieve

    Returns:
        float in [0, 1] — fraction of correct retrievals
    """
    embeddings = np.array(embeddings, dtype=np.float32)
    labels     = np.array(labels)
    N          = len(labels)

    # Cosine similarity matrix  (N, N)
    norms = np.linalg.norm(embeddings, axis=1, keepdims=True) + 1e-10
    normed = embeddings / norms
    sim = normed @ normed.T                     # (N, N)
    np.fill_diagonal(sim, -np.inf)              # exclude self

    correct = 0
    for i in range(N):
        top_k_idx = np.argpartition(sim[i], -k)[-k:]   # fast top-k
        if labels[i] in labels[top_k_idx]:
            correct += 1

    return correct / N


# ─────────────────────────────────────────────────────────────
# 1.8  t-SNE Visualisation
# ─────────────────────────────────────────────────────────────

def plot_tsne(embeddings: np.ndarray,
              labels:     np.ndarray,
              title:      str   = 't-SNE Embedding Space',
              save_path:  str   = 'graphs/tsne.png',
              max_points: int   = 3000):
    """
    Reduce embeddings to 2-D with t-SNE and save a scatter plot
    coloured by class label.

    Args:
        embeddings : (N, D)
        labels     : (N,)
        title      : plot title
        save_path  : where to save the PNG
        max_points : subsample if N > max_points (for speed)
    """
    from sklearn.manifold import TSNE

    # Subsample for speed while keeping class balance
    N = len(labels)
    if N > max_points:
        idx = np.random.choice(N, max_points, replace=False)
        embeddings = embeddings[idx]
        labels     = labels[idx]

    print(f"  [t-SNE] fitting {len(labels)} points for '{title}' ...")
    reducer = TSNE(n_components=2, perplexity=30, random_state=42,
                   n_iter=1000, learning_rate='auto', init='pca')
    reduced = reducer.fit_transform(embeddings)

    plt.figure(figsize=(12, 9))
    scatter = plt.scatter(
        reduced[:, 0], reduced[:, 1],
        c=labels, cmap='tab20', alpha=0.65, s=7
    )
    cbar = plt.colorbar(scatter)
    cbar.set_label('Class Index', rotation=270, labelpad=15)
    plt.title(title, fontsize=14)
    plt.xlabel('t-SNE dim 1')
    plt.ylabel('t-SNE dim 2')
    plt.tight_layout()
    os.makedirs(os.path.dirname(save_path) or '.', exist_ok=True)
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"  [✓] t-SNE saved  →  {save_path}")


# ─────────────────────────────────────────────────────────────
# 1.9  Retrieval Grid Visualisation
# ─────────────────────────────────────────────────────────────

def show_retrieval(query_indices:  list,
                   embeddings:     np.ndarray,
                   image_paths:    list,
                   labels:         np.ndarray,
                   class_names:    list,
                   k:              int  = 5,
                   save_path:      str  = 'graphs/retrieval.png'):
    """
    For each query index display a grid row:
        Column 0          : query image
        Columns 1 .. k    : top-k nearest neighbours
        Border colour     : GREEN = correct class | RED = wrong class

    Args:
        query_indices : list of indices into embeddings / image_paths
        embeddings    : (N, D) numpy array
        image_paths   : list of N image file paths
        labels        : (N,)  integer labels
        class_names   : mapping int -> class name string
        k             : number of neighbours shown per query
        save_path     : output PNG path
    """
    embeddings = np.array(embeddings, dtype=np.float32)
    labels     = np.array(labels)

    # Cosine similarity
    norms  = np.linalg.norm(embeddings, axis=1, keepdims=True) + 1e-10
    normed = embeddings / norms
    sim    = normed @ normed.T
    np.fill_diagonal(sim, -np.inf)

    n_q = len(query_indices)
    cols = k + 1
    fig, axes = plt.subplots(n_q, cols,
                             figsize=(2.5 * cols, 2.8 * n_q))
    if n_q == 1:
        axes = axes[np.newaxis, :]   # always 2-D

    for row, q_idx in enumerate(query_indices):
        q_label = labels[q_idx]

        # Retrieve top-k neighbours
        top_k_idx = np.argsort(sim[q_idx])[::-1][:k]

        # ── Column 0: query ──
        ax = axes[row, 0]
        _show_img(ax, image_paths[q_idx])
        cls_name = class_names[q_label] if q_label < len(class_names) \
                   else str(q_label)
        ax.set_title(f'Query\n{cls_name}', fontsize=7, color='navy')
        _set_border(ax, 'navy', lw=3)
        ax.axis('off')

        # ── Columns 1..k: neighbours ──
        for col, n_idx in enumerate(top_k_idx):
            ax = axes[row, col + 1]
            _show_img(ax, image_paths[n_idx])
            match      = bool(labels[n_idx] == q_label)
            color      = 'green' if match else 'red'
            tick       = '✓' if match else '✗'
            n_cls_name = class_names[labels[n_idx]] \
                         if labels[n_idx] < len(class_names) \
                         else str(labels[n_idx])
            ax.set_title(f'{tick} Top-{col+1}\n{n_cls_name}',
                         fontsize=7, color=color)
            _set_border(ax, color, lw=3)
            ax.axis('off')

    plt.suptitle('Retrieval Results  (green=correct | red=wrong)',
                 fontsize=11, y=1.01)
    plt.tight_layout()
    os.makedirs(os.path.dirname(save_path) or '.', exist_ok=True)
    plt.savefig(save_path, dpi=120, bbox_inches='tight')
    plt.close()
    print(f"[✓] Retrieval grid saved  →  {save_path}")


# ── helpers ──────────────────────────────────────────────────

def _show_img(ax, path):
    try:
        img = Image.open(path).convert('RGB')
        ax.imshow(img)
    except Exception:
        ax.set_facecolor('#cccccc')


def _set_border(ax, color, lw=3):
    for spine in ax.spines.values():
        spine.set_visible(True)
        spine.set_edgecolor(color)
        spine.set_linewidth(lw)
