# inference.py
"""
Standalone inference — works completely independently of training code.

Usage (single image):
    python inference.py \
        --images path/to/img.jpg \
        --weights weights/Exp1_Contrastive/best.pth

Usage (multiple images):
    python inference.py \
        --images img1.jpg img2.jpg img3.jpg \
        --weights weights/Exp2_Triplet_Random/best.pth \
        --save_npy my_embeddings.npy

The script prints the embedding shape and L2-norm (should be ~1.0
because embeddings are L2-normalised inside the network).
"""

import argparse
import os

import numpy as np
import torch
import torchvision.transforms as T
from PIL import Image

from model import EmbeddingNet, load_checkpoint


# ─────────────────────────────────────────────────────────────
# Same preprocessing as training (eval mode)
# ─────────────────────────────────────────────────────────────

INFERENCE_TRANSFORM = T.Compose([
    T.Resize(256),
    T.CenterCrop(224),
    T.ToTensor(),
    T.Normalize(mean=[0.485, 0.456, 0.406],
                std=[0.229, 0.224, 0.225]),
])


# ─────────────────────────────────────────────────────────────
# Core inference function (importable by other modules)
# ─────────────────────────────────────────────────────────────

def run_inference(image_paths:    list,
                  weights_path:   str,
                  embedding_dim:  int           = 128,
                  device:         torch.device  = None) -> np.ndarray:
    """
    Generate L2-normalised embedding vectors for a list of images.

    Args:
        image_paths   : list of file paths
        weights_path  : path to saved .pth checkpoint
        embedding_dim : must match checkpoint (default 128)
        device        : torch device (auto-detected if None)

    Returns:
        numpy array of shape (N, embedding_dim)
    """
    if device is None:
        device = torch.device('cuda' if torch.cuda.is_available()
                              else 'cpu')

    # Load model
    model = EmbeddingNet(embedding_dim=embedding_dim).to(device)
    load_checkpoint(model, weights_path, device)
    model.eval()

    embeddings = []

    with torch.no_grad():
        for path in image_paths:
            if not os.path.isfile(path):
                raise FileNotFoundError(f"Image not found: {path}")

            img    = Image.open(path).convert('RGB')
            tensor = INFERENCE_TRANSFORM(img).unsqueeze(0).to(device)  # (1,3,224,224)
            emb    = model(tensor).squeeze(0).cpu().numpy()             # (D,)
            embeddings.append(emb)

            norm = float(np.linalg.norm(emb))
            print(f"  {os.path.basename(path):>40}  "
                  f"shape={emb.shape}  norm={norm:.5f}")

    return np.stack(embeddings, axis=0)   # (N, D)


# ─────────────────────────────────────────────────────────────
# Similarity helper
# ─────────────────────────────────────────────────────────────

def cosine_similarity(emb1: np.ndarray, emb2: np.ndarray) -> float:
    """Cosine similarity between two embedding vectors."""
    n1 = np.linalg.norm(emb1) + 1e-10
    n2 = np.linalg.norm(emb2) + 1e-10
    return float(np.dot(emb1 / n1, emb2 / n2))


# ─────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description='Generate embeddings for one or more images')
    parser.add_argument('--images',        nargs='+', required=True,
                        help='One or more image file paths')
    parser.add_argument('--weights',       required=True,
                        help='Path to .pth checkpoint')
    parser.add_argument('--embedding_dim', type=int, default=128)
    parser.add_argument('--save_npy',      default=None,
                        help='Optional: save embeddings to .npy file')
    args = parser.parse_args()

    print(f"\nRunning inference on {len(args.images)} image(s) ...")
    embs = run_inference(args.images, args.weights, args.embedding_dim)

    print(f"\nOutput shape : {embs.shape}")

    # If more than one image, print pairwise cosine similarities
    if len(args.images) > 1:
        print("\nPairwise cosine similarities:")
        for i in range(len(args.images)):
            for j in range(i + 1, len(args.images)):
                sim = cosine_similarity(embs[i], embs[j])
                print(f"  {os.path.basename(args.images[i])}  ↔  "
                      f"{os.path.basename(args.images[j])}  :  {sim:.4f}")

    if args.save_npy:
        np.save(args.save_npy, embs)
        print(f"\n[✓] Embeddings saved  →  {args.save_npy}")


if __name__ == '__main__':
    main()
