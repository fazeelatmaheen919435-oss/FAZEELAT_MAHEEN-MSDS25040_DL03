# loss.py
"""
Loss functions for Deep Metric Learning
  1.4  ContrastiveLoss   (margin = 1.0)
  1.5  TripletLoss       (margin = 0.2)
  1.6  batch_hard_mining (margin = 0.2)
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


# ─────────────────────────────────────────────────────────────
# 1.4  Contrastive Loss
# L = y * D^2 + (1 - y) * max(0, margin - D)^2
# ─────────────────────────────────────────────────────────────

class ContrastiveLoss(nn.Module):
    """
    Contrastive loss for siamese / pair-based metric learning.

    Args:
        margin (float): Push negative pairs apart by at least `margin`.
                        Assignment specifies margin = 1.0.
    """

    def __init__(self, margin: float = 1.0):
        super(ContrastiveLoss, self).__init__()
        self.margin = margin

    def forward(self, emb1: torch.Tensor,
                emb2: torch.Tensor,
                target: torch.Tensor) -> torch.Tensor:
        """
        Args:
            emb1   : (B, D)  L2-normalised embeddings for image 1
            emb2   : (B, D)  L2-normalised embeddings for image 2
            target : (B,)    1 = same class, 0 = different class

        Returns:
            Scalar mean loss.
        """
        D = F.pairwise_distance(emb1, emb2, p=2)   # (B,)
        y = target.float()

        positive_loss = y * D.pow(2)
        negative_loss = (1.0 - y) * F.relu(self.margin - D).pow(2)
        loss = positive_loss + negative_loss
        return loss.mean()


# ─────────────────────────────────────────────────────────────
# 1.5  Triplet Loss
# L = max(0, D(a,p) - D(a,n) + margin)
# ─────────────────────────────────────────────────────────────

class TripletLoss(nn.Module):
    """
    Standard triplet loss.

    Args:
        margin (float): Assignment specifies margin = 0.2.
    """

    def __init__(self, margin: float = 0.2):
        super(TripletLoss, self).__init__()
        self.margin = margin

    def forward(self, anchor:   torch.Tensor,
                      positive: torch.Tensor,
                      negative: torch.Tensor) -> torch.Tensor:
        """
        Args:
            anchor, positive, negative : (B, D) L2-normalised embeddings

        Returns:
            Scalar mean loss.
        """
        d_pos = F.pairwise_distance(anchor, positive, p=2)  # (B,)
        d_neg = F.pairwise_distance(anchor, negative, p=2)  # (B,)
        loss  = F.relu(d_pos - d_neg + self.margin)
        return loss.mean()


# ─────────────────────────────────────────────────────────────
# 1.6  Batch Hard Negative Mining
# ─────────────────────────────────────────────────────────────

def batch_hard_mining(embeddings: torch.Tensor,
                      labels:     torch.Tensor,
                      margin:     float = 0.2) -> torch.Tensor:
    """
    Batch-hard triplet mining.

    For EACH anchor in the batch:
        hardest positive  = same-class sample with MAXIMUM distance
        hardest negative  = diff-class sample with MINIMUM distance

    Args:
        embeddings : (B, D)  L2-normalised embeddings
        labels     : (B,)    integer class labels
        margin     : triplet margin (default 0.2)

    Returns:
        Scalar mean loss over all valid hard triplets.
    """
    B = embeddings.size(0)

    # Full pairwise Euclidean distance matrix  (B, B)
    dist = torch.cdist(embeddings, embeddings, p=2)

    # Boolean masks  (B, B)
    labels_col  = labels.unsqueeze(0)        # (1, B)
    labels_row  = labels.unsqueeze(1)        # (B, 1)
    same_mask   = labels_row == labels_col   # True where same class
    diff_mask   = ~same_mask

    # Remove diagonal (self-distances) from positive mask
    eye = torch.eye(B, dtype=torch.bool, device=embeddings.device)
    pos_mask = same_mask & ~eye              # (B, B)

    # Large sentinel for negative masking (we want min over diff_mask)
    INF = torch.tensor(1e9, device=embeddings.device)

    # Hardest positive per anchor: max distance among same-class
    pos_dist = dist.clone()
    pos_dist[~pos_mask] = -INF               # ignore non-positives
    hardest_pos, _ = pos_dist.max(dim=1)     # (B,)

    # Hardest negative per anchor: min distance among diff-class
    neg_dist = dist.clone()
    neg_dist[~diff_mask] = INF               # ignore non-negatives
    hardest_neg, _ = neg_dist.min(dim=1)     # (B,)

    # Only compute loss for anchors that have at least one pos AND one neg
    valid = pos_mask.any(dim=1) & diff_mask.any(dim=1)  # (B,)

    if valid.sum() == 0:
        return torch.tensor(0.0, device=embeddings.device,
                            requires_grad=True)

    loss = F.relu(hardest_pos[valid] - hardest_neg[valid] + margin)
    return loss.mean()
