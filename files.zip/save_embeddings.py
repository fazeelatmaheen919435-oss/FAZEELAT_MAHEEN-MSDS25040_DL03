# save_embeddings.py
"""
1.10  Precompute, save, and load embeddings.

Usage:
    python save_embeddings.py \
        --dataset_path /path/to/101_ObjectCategories \
        --weights      weights/Exp1_Contrastive/best.pth \
        --split        test \
        --save_dir     embeddings
"""

import argparse
import os

import numpy as np
import torch
from torch.utils.data import DataLoader
from tqdm import tqdm

from model   import EmbeddingNet, load_checkpoint
from dataset import (load_caltech101, split_dataset,
                     BaseDataset, get_transforms)


# ─────────────────────────────────────────────────────────────
# Compute & save
# ─────────────────────────────────────────────────────────────

def compute_embeddings(model, dataset, device, batch_size=64):
    """
    Pass all images through the model and return
    (embeddings np.ndarray (N,D), labels np.ndarray (N,)).
    """
    loader = DataLoader(dataset, batch_size=batch_size,
                        shuffle=False, num_workers=2,
                        pin_memory=True)
    model.eval()
    all_embs, all_labs = [], []

    with torch.no_grad():
        for imgs, labels in tqdm(loader, desc='  computing embeddings'):
            imgs  = imgs.to(device)
            embs  = model(imgs).cpu().numpy()
            all_embs.append(embs)
            all_labs.extend(labels.numpy())

    return (np.concatenate(all_embs, axis=0),
            np.array(all_labs, dtype=np.int64))


def save_embeddings(embeddings, labels, prefix):
    """Save embeddings and labels as .npy files."""
    np.save(f'{prefix}_embeddings.npy', embeddings)
    np.save(f'{prefix}_labels.npy',     labels)
    print(f"[✓] Saved  {prefix}_embeddings.npy  "
          f"({embeddings.shape[0]} × {embeddings.shape[1]})")
    print(f"[✓] Saved  {prefix}_labels.npy")


def load_embeddings(prefix):
    """Load previously saved embeddings and labels."""
    emb_path = f'{prefix}_embeddings.npy'
    lab_path = f'{prefix}_labels.npy'
    if not os.path.exists(emb_path):
        raise FileNotFoundError(f"Embeddings not found: {emb_path}")
    embeddings = np.load(emb_path)
    labels     = np.load(lab_path)
    print(f"[✓] Loaded {emb_path}  ({embeddings.shape})")
    return embeddings, labels


# ─────────────────────────────────────────────────────────────
# CLI entry-point
# ─────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description='Precompute and save embeddings')
    parser.add_argument('--dataset_path',  required=True,
                        help='Root folder of Caltech-101')
    parser.add_argument('--weights',       required=True,
                        help='Path to .pth checkpoint')
    parser.add_argument('--split',         default='test',
                        choices=['train', 'val', 'test', 'all'])
    parser.add_argument('--save_dir',      default='embeddings')
    parser.add_argument('--embedding_dim', type=int, default=128)
    parser.add_argument('--batch_size',    type=int, default=64)
    args = parser.parse_args()

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Device: {device}")

    os.makedirs(args.save_dir, exist_ok=True)

    samples, classes, _ = load_caltech101(args.dataset_path)
    train_s, val_s, test_s = split_dataset(samples)
    split_map = {'train': train_s, 'val': val_s, 'test': test_s}

    model = EmbeddingNet(embedding_dim=args.embedding_dim).to(device)
    load_checkpoint(model, args.weights, device)

    splits = list(split_map.keys()) if args.split == 'all' \
             else [args.split]

    for split_name in splits:
        print(f"\n--- {split_name} split ---")
        ds = BaseDataset(split_map[split_name],
                         transform=get_transforms(train=False))
        embs, labs = compute_embeddings(model, ds, device,
                                        args.batch_size)
        prefix = os.path.join(args.save_dir, split_name)
        save_embeddings(embs, labs, prefix)


if __name__ == '__main__':
    main()
