# dataset.py
"""
Dataset utilities for Deep Metric Learning.
Covers:
  - Caltech-101 loading
  - 70 / 15 / 15 stratified split
  - BaseDataset            (single images + labels)
  - ContrastiveDataset     (Section 1.2)
  - TripletDataset         (Section 1.3)
"""

import os
import random
from collections import defaultdict
from typing import List, Tuple

import numpy as np
from PIL import Image
from torch.utils.data import Dataset
import torchvision.transforms as T


# ─────────────────────────────────────────────────────────────
# Transforms
# ─────────────────────────────────────────────────────────────

def get_transforms(train: bool = True):
    if train:
        return T.Compose([
            T.Resize(256),
            T.RandomCrop(224),
            T.RandomHorizontalFlip(),
            T.ColorJitter(brightness=0.3, contrast=0.3,
                          saturation=0.2, hue=0.05),
            T.ToTensor(),
            T.Normalize(mean=[0.485, 0.456, 0.406],
                        std=[0.229, 0.224, 0.225]),
        ])
    else:
        return T.Compose([
            T.Resize(256),
            T.CenterCrop(224),
            T.ToTensor(),
            T.Normalize(mean=[0.485, 0.456, 0.406],
                        std=[0.229, 0.224, 0.225]),
        ])


# ─────────────────────────────────────────────────────────────
# Caltech-101 loader
# ─────────────────────────────────────────────────────────────

def load_caltech101(root: str):
    """
    Scan root directory for class folders.
    Returns:
        samples      : list of (img_path, label_int)
        classes      : list of class name strings  (sorted)
        class_to_idx : dict {class_name: int}
    """
    classes = sorted([
        d for d in os.listdir(root)
        if os.path.isdir(os.path.join(root, d))
        and d != 'BACKGROUND_Google'
    ])
    class_to_idx = {cls: idx for idx, cls in enumerate(classes)}

    samples: List[Tuple[str, int]] = []
    for cls in classes:
        folder = os.path.join(root, cls)
        for fname in sorted(os.listdir(folder)):
            if fname.lower().endswith(('.jpg', '.jpeg', '.png')):
                samples.append((os.path.join(folder, fname),
                                 class_to_idx[cls]))

    print(f"[dataset] {len(classes)} classes | {len(samples)} images")
    return samples, classes, class_to_idx


def split_dataset(samples, train_ratio=0.70, val_ratio=0.15, seed=42):
    """
    Stratified split: 70 % train | 15 % val | 15 % test.
    Ensures every class appears in every split.
    """
    rng = random.Random(seed)

    class_buckets: dict = defaultdict(list)
    for item in samples:
        class_buckets[item[1]].append(item)

    train, val, test = [], [], []
    for lbl, items in class_buckets.items():
        shuffled = items[:]
        rng.shuffle(shuffled)
        n = len(shuffled)
        n_train = max(1, int(n * train_ratio))
        n_val   = max(1, int(n * val_ratio))
        train += shuffled[:n_train]
        val   += shuffled[n_train: n_train + n_val]
        test  += shuffled[n_train + n_val:]

    print(f"[split] train={len(train)} | val={len(val)} | test={len(test)}")
    return train, val, test


# ─────────────────────────────────────────────────────────────
# BaseDataset  —  single-image loader
# ─────────────────────────────────────────────────────────────

class BaseDataset(Dataset):
    """Standard image-label dataset used for embedding extraction."""

    def __init__(self, samples: List[Tuple[str, int]], transform=None):
        self.samples   = samples
        self.transform = transform

        # per-class index map for fast sampling
        self.class_to_indices: dict = defaultdict(list)
        for idx, (_, lbl) in enumerate(samples):
            self.class_to_indices[lbl].append(idx)

        self.classes = sorted(self.class_to_indices.keys())

    # expose paths for visualisation helpers
    @property
    def image_paths(self):
        return [s[0] for s in self.samples]

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        path, label = self.samples[idx]
        img = Image.open(path).convert('RGB')
        if self.transform:
            img = self.transform(img)
        return img, label


# ─────────────────────────────────────────────────────────────
# 1.2  ContrastiveDataset
# ─────────────────────────────────────────────────────────────

class ContrastiveDataset(Dataset):
    """
    Returns (img1, img2, pair_label) where
        pair_label = 1  →  positive pair  (same class)
        pair_label = 0  →  negative pair  (different class)

    Positive and negative pairs are sampled with equal
    probability  p = 0.5  as required by the assignment.
    """

    def __init__(self, base: BaseDataset):
        self.base              = base
        self.class_to_indices  = base.class_to_indices
        self.classes           = base.classes

    def __len__(self):
        return len(self.base)

    def __getitem__(self, index):
        img1, label1 = self.base[index]

        # ── Equal probability coin flip ──
        if random.random() < 0.5:
            # ── POSITIVE pair ──
            candidates = self.class_to_indices[label1]
            if len(candidates) > 1:
                pos_idx = index
                while pos_idx == index:
                    pos_idx = random.choice(candidates)
            else:
                pos_idx = candidates[0]      # only one image in class
            img2, _ = self.base[pos_idx]
            pair_label = 1
        else:
            # ── NEGATIVE pair ──
            neg_class = random.choice(
                [c for c in self.classes if c != label1]
            )
            neg_idx = random.choice(self.class_to_indices[neg_class])
            img2, _ = self.base[neg_idx]
            pair_label = 0

        return img1, img2, pair_label


# ─────────────────────────────────────────────────────────────
# 1.3  TripletDataset
# ─────────────────────────────────────────────────────────────

class TripletDataset(Dataset):
    """
    Returns (anchor, positive, negative) where
        positive → same class as anchor, DIFFERENT image
        negative → image from a DIFFERENT class
    """

    def __init__(self, base: BaseDataset):
        self.base             = base
        self.class_to_indices = base.class_to_indices
        self.classes          = base.classes

    def __len__(self):
        return len(self.base)

    def __getitem__(self, index):
        anchor_img, anchor_label = self.base[index]

        # ── Positive ──
        same = self.class_to_indices[anchor_label]
        pos_idx = index
        if len(same) > 1:
            while pos_idx == index:
                pos_idx = random.choice(same)
        pos_img, _ = self.base[pos_idx]

        # ── Negative ──
        neg_class = random.choice(
            [c for c in self.classes if c != anchor_label]
        )
        neg_idx = random.choice(self.class_to_indices[neg_class])
        neg_img, _ = self.base[neg_idx]

        return anchor_img, pos_img, neg_img
