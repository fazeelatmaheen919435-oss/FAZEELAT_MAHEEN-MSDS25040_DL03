# model.py
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.models as models


class EmbeddingNet(nn.Module):
    """
    ResNet-50 backbone (pretrained ImageNet) with classification
    head replaced by a FC projection layer + L2 normalisation.
    Architecture:
        Input (224x224x3)
        -> ResNet-50 backbone (frozen BN, fine-tune last 2 blocks)
        -> Global Average Pooling  (2048,)
        -> Linear 2048 -> 128
        -> L2 Normalise
        -> Embedding vector (dim=128)
    """
    def __init__(self, embedding_dim: int = 128):
        super(EmbeddingNet, self).__init__()

        backbone = models.resnet50(weights=models.ResNet50_Weights.IMAGENET1K_V1)

        # Strip the final FC classification layer
        # backbone.children() order:
        #   conv1, bn1, relu, maxpool, layer1, layer2, layer3, layer4, avgpool, fc
        self.backbone = nn.Sequential(*list(backbone.children())[:-1])
        # Output shape after backbone: (B, 2048, 1, 1)

        # Projection head  2048 -> embedding_dim
        self.projection = nn.Linear(2048, embedding_dim)

        # Optionally freeze early layers (layer1, layer2) to speed up training
        self._freeze_early_layers()

    def _freeze_early_layers(self):
        """Freeze conv1, bn1, layer1, layer2 — fine-tune layer3, layer4."""
        freeze_names = {'0', '1', '4', '5'}   # indices in backbone Sequential
        for name, param in self.backbone.named_parameters():
            top = name.split('.')[0]
            if top in freeze_names:
                param.requires_grad = False

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        features = self.backbone(x)                        # (B, 2048, 1, 1)
        features = features.view(features.size(0), -1)     # (B, 2048)
        embeddings = self.projection(features)             # (B, embedding_dim)
        embeddings = F.normalize(embeddings, p=2, dim=1)   # L2 normalise
        return embeddings


# ─────────────────────────────────────────────────────────────
# Checkpoint utilities
# ─────────────────────────────────────────────────────────────

def save_checkpoint(model: nn.Module, path: str, extra: dict = None):
    """Save model state_dict (+ optional extra info) to path."""
    payload = {'state_dict': model.state_dict()}
    if extra:
        payload.update(extra)
    torch.save(payload, path)
    print(f"[✓] Checkpoint saved  →  {path}")


def load_checkpoint(model: nn.Module, path: str,
                    device: torch.device) -> nn.Module:
    """Load model weights from checkpoint."""
    payload = torch.load(path, map_location=device)
    state = payload['state_dict'] if 'state_dict' in payload else payload
    model.load_state_dict(state)
    model.eval()
    print(f"[✓] Checkpoint loaded ←  {path}")
    return model
